import Parser from "rss-parser";
import fs from "fs";

const parser = new Parser({ timeout: 20000, headers: { "User-Agent": "DailyNewsRadar/1.0" } });
const categories = [
  { id:"politics", name:"정치", query:"정치 국회 정부" },
  { id:"economy", name:"경제", query:"경제 증시 기업 금융" },
  { id:"society", name:"사회", query:"사회 사건 교육 노동" },
  { id:"world", name:"국제", query:"국제 해외 외교" },
  { id:"tech", name:"IT·과학", query:"IT 과학 인공지능 기술" },
  { id:"sports", name:"스포츠", query:"스포츠 축구 야구" },
  { id:"culture", name:"문화", query:"문화 연예 영화 음악" }
];
const stopwords = new Set(["기자","오늘","관련","대한","통해","위해","이번","지난","이후","당시","우리","그는","했다","한다","있는","것으로","것은","밝혔다","전했다","따르면","뉴스","속보","단독","종합","영상","사진"]);
function clean(s=""){return String(s).replace(/<[^>]*>/g," ").replace(/&amp;/g,"&").replace(/\s+/g," ").trim();}
function keywords(text){
 const words=(text.match(/[가-힣]{2,}|[A-Za-z][A-Za-z0-9.-]{2,}/g)||[]).map(w=>w.toLowerCase()).filter(w=>!stopwords.has(w));
 const counts=new Map(); for(const w of words)counts.set(w,(counts.get(w)||0)+1);
 return [...counts].sort((a,b)=>b[1]-a[1]).slice(0,8).map(x=>x[0]);
}
function categoryFor(item){
 const t=(item.title+" "+item.description).toLowerCase();
 const rules=[
 ["sports",/축구|야구|농구|배구|올림픽|선수|감독|리그|스포츠|손흥민|프로야구/],
 ["tech",/인공지능|ai\b|반도체|과학|기술|로봇|스마트폰|소프트웨어|정보통신/],
 ["world",/미국|중국|일본|유럽|우크라|러시아|국제|해외|트럼프|외교|중동/],
 ["politics",/국회|대통령|정당|정치|정부|장관|총리|선거|여당|야당/],
 ["economy",/경제|증시|주가|금리|환율|부동산|기업|은행|물가|수출|코스피/],
 ["culture",/연예|배우|가수|영화|드라마|음악|문화|공연|웹툰/],
 ["society",/사회|사건|사고|경찰|법원|교육|학교|노동|복지|날씨|환경/]
 ];
 for(const [id,re] of rules)if(re.test(t))return id; return "society";
}
function sourceName(url=""){try{return new URL(url).hostname.replace(/^www\./,"");}catch{return "언론사";}}
function normalizeTitle(s=""){return clean(s).toLowerCase().replace(/[^\p{L}\p{N}]/gu,"").slice(0,55);}
function summarize(description,title){
 const d=clean(description);
 if(d&&d.length>35)return d.length>180?d.slice(0,177)+"…":d;
 return `${title}에 관한 보도입니다. 원문에서 발표 내용과 후속 상황을 확인할 수 있습니다.`;
}
async function main(){
 const raw=[];
 for(const c of categories){
  const url=`https://news.google.com/rss/search?q=${encodeURIComponent(c.query)}&hl=ko&gl=KR&ceid=KR:ko`;
  try{
   const feed=await parser.parseURL(url);
   for(const item of (feed.items||[]).slice(0,35)){
    raw.push({title:clean(item.title),description:clean(item.contentSnippet||item.content||item.summary||""),link:item.link,pubDate:item.isoDate||item.pubDate,source:clean(item.creator||sourceName(item.link))});
   }
  }catch(e){console.error("RSS 수집 실패",c.name,e.message);}
 }
 if(!raw.length)throw new Error("뉴스 RSS 수집 결과가 없습니다.");
 const grouped=new Map();
 for(const item of raw){
  const key=normalizeTitle(item.title); if(!key)continue;
  if(!grouped.has(key))grouped.set(key,{...item,sources:new Set(),mentions:0});
  const g=grouped.get(key);g.sources.add(item.source);g.mentions++;
  if((item.description||"").length>(g.description||"").length)g.description=item.description;
 }
 const articles=[...grouped.values()].map((x,i)=>{
  const ageHours=Math.max(0,(Date.now()-new Date(x.pubDate||Date.now()).getTime())/36e5);
  const freshness=Math.max(0,24-ageHours)/24;
  const score=Math.round(x.sources.size*18+x.mentions*5+freshness*25);
  return {id:String(i+1),title:x.title,description:summarize(x.description,x.title),url:x.link,source:[...x.sources][0]||x.source,sources:[...x.sources],pubDate:x.pubDate||null,category:categoryFor(x),score,keywords:keywords(x.title+" "+(x.description||"")).slice(0,5)};
 }).sort((a,b)=>b.score-a.score);
 const byCategory={};
 for(const c of categories){
  const list=articles.filter(a=>a.category===c.id).sort((a,b)=>b.score-a.score);
  const freq={};list.forEach(a=>a.keywords.forEach(k=>freq[k]=(freq[k]||0)+1));
  const popular=Object.entries(freq).sort((a,b)=>b[1]-a[1]).slice(0,6).map(x=>x[0]);
  byCategory[c.id]={articles:list.slice(0,15),keywords:popular,trendTitle:list.length?`${c.name} 분야 핵심 흐름: ${popular.slice(0,3).join(" · ")}`:`${c.name} 뉴스 수집 중`};
 }
 const data={updatedAt:new Date().toISOString(),date:new Intl.DateTimeFormat("ko-KR",{timeZone:"Asia/Seoul",dateStyle:"full"}).format(new Date()),rankingBasis:"언론사 중복 보도 수 + 최신성 기반 참고 점수 (실제 조회수 아님)",top:articles.slice(0,15),categories:byCategory,counts:Object.fromEntries(Object.entries(byCategory).map(([k,v])=>[k,v.articles.length]))};
 fs.mkdirSync("public",{recursive:true});fs.writeFileSync("public/data.json",JSON.stringify(data,null,2),"utf8");
 console.log(`뉴스 데이터 저장 완료: ${raw.length}건 수집, ${articles.length}개 이슈`);
}
main().catch(e=>{console.error(e);process.exit(1);});
