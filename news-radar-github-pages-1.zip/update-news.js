import Parser from "rss-parser";
import fs from "fs";

const parser = new Parser({ timeout: 20000, headers: { "User-Agent": "DailyNewsRadar/1.0" } });
const categories = [
  { id:"politics", name:"정치", query:"정치 국회 정부" },
  { id:"economy", name:"경제", query:"경제 증시 기업 금융" },
  { id:"society", name:"사회", query:"사회 사건 교육 노동" },
  { id:"world", name:"국제", query:"국제 해외 외교" },
  { id:"tech", name:"IT·과학", query:"IT 과학 인공지능 기술" },
  { id:"sports", name:"스포츠", query:"스포츠 축구 야구" },
  { id:"culture", name:"문화", query:"문화 연예 영화 음악" },
  { id:"other", name:"기타", query:"주요 뉴스 종합 이슈" }
];

const stopwords = new Set(["기자","오늘","관련","대한","통해","위해","이번","지난","이후","당시","우리","그는","했다","한다","있는","것으로","것은","밝혔다","전했다","따르면","뉴스","속보","단독","종합","영상","사진"]);
function clean(s=""){return String(s).replace(/<[^>]*>/g," ").replace(/&amp;/g,"&").replace(/\s+/g," ").trim();}
function keywords(text){
 const words=(text.match(/[가-힣]{2,}|[A-Za-z][A-Za-z0-9.-]{2,}/g)||[]).map(w=>w.toLowerCase()).filter(w=>!stopwords.has(w));
 const counts=new Map(); for(const w of words)counts.set(w,(counts.get(w)||0)+1);
 return [...counts].sort((a,b)=>b[1]-a[1]).slice(0,8).map(x=>x[0]);
}

/*
 * 한두 개의 일반 단어만으로 분야를 단정하지 않는다.
 * 특히 스포츠는 종목·경기·대회 등 핵심 표현이 확인될 때만 인정하고,
 * 검찰·검사·고용노동부 등 비스포츠 기관·직무 표현이 중심인 기사는 제외한다.
 */
const categoryRules = {
 politics: ["국회","대통령","정당","정치","정부","장관","총리","선거","여당","야당","국정","의원","정책"],
 economy: ["경제","증시","주가","금리","환율","부동산","기업","은행","물가","수출","코스피","코스닥","투자","실적"],
 society: ["사회","사건","사고","경찰","법원","교육","학교","노동","복지","날씨","환경","검찰","검사","고용노동부","노동부","재판","구속","수사"],
 world: ["미국","중국","일본","유럽","우크라","러시아","국제","해외","트럼프","외교","중동","정상회담","전쟁"],
 tech: ["인공지능","반도체","과학","기술","로봇","스마트폰","소프트웨어","정보통신","생성형ai","챗gpt","우주"],
 culture: ["연예","배우","가수","영화","드라마","음악","문화","공연","웹툰","방송","아이돌","전시"]
};
const sportsCore = [
 "축구","야구","농구","배구","골프","테니스","탁구","배드민턴","수영","육상","복싱","격투기",
 "올림픽","월드컵","아시안게임","프로야구","k리그","mlb","nba","wbc","uefa","fifa",
 "경기","리그","챔피언십","결승전","준결승","플레이오프","득점","골","홈런","타율","타점",
 "우승","준우승","감독","코치","구단","대표팀","국가대표","선발전","이적","선수단","스포츠",
 "손흥민","김민재","이강인","류현진","김하성","오타니","페이커","안세영","신유빈"
];
const nonSportsExclusions = [
 "검찰","검사","고용노동부","노동부","법무부","대검찰청","검찰청","공수처","경찰청",
 "수사","기소","구속","재판","법원","판결","피의자","피고인","노동위원회","근로감독"
];
function countMatches(text, terms){
 return terms.reduce((n,term)=>n+(text.includes(term.toLowerCase())?1:0),0);
}
function categoryFor(item){
 const t=(String(item.title||"")+" "+String(item.description||"")).toLowerCase();
 const scores=Object.entries(categoryRules).map(([id,terms])=>[id,countMatches(t,terms)])
   .filter(([,score])=>score>0).sort((a,b)=>b[1]-a[1]);
 const sportsScore=countMatches(t,sportsCore);
 const excluded=countMatches(t,nonSportsExclusions)>0;

 // 스포츠 핵심 키워드가 없거나 비스포츠 기관·수사 문맥이면 스포츠 후보에서 제외
 if(sportsScore>0 && !excluded) scores.push(["sports",sportsScore]);
 scores.sort((a,b)=>b[1]-a[1]);

 if(!scores.length)return "other";
 const highest=scores[0][1];
 const leaders=scores.filter(([,score])=>score===highest);
 // 동률이거나 1점 차이로 여러 분야가 경쟁하면 특정 분야로 단정하지 않는다.
 if(leaders.length>1 || (scores.length>1 && highest-scores[1][1]<=1))return "other";
 // 약한 단서 하나만 있는 경우도 기타로 보낸다.
 if(highest<2)return "other";
 return scores[0][0];
}
function sourceName(url=""){try{return new URL(url).hostname.replace(/^www\./,"");}catch{return "언론사";}}
function normalizeTitle(s=""){return clean(s).toLowerCase().replace(/[^\p{L}\p{N}]/gu,"").slice(0,55);}
function summarize(description,title){
 const d=clean(description);
 if(d&&d.length>35)return d.length>180?d.slice(0,177)+"…":d;
 return `${title}에 관한 보도입니다. 원문에서 발표 내용과 후속 상황을 확인할 수 있습니다.`;
}
function decodeHtml(s=""){
 return String(s).replace(/&amp;/g,"&").replace(/&quot;/g,'"').replace(/&#39;|&apos;/g,"'").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&#(\d+);/g,(_,n)=>String.fromCodePoint(Number(n)));
}
async function collectDcInside(){
 const output={updatedAt:new Date().toISOString(),sourceUrl:"https://gall.dcinside.com/board/lists/?id=dcbest",posts:[],error:null};
 try{
  const response=await fetch(output.sourceUrl,{
   headers:{"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36","Accept":"text/html,application/xhtml+xml"},
   signal:AbortSignal.timeout(20000)
  });
  if(!response.ok)throw new Error(`DC인사이드 응답 오류 (${response.status})`);
  const html=await response.text();
  // 실시간 베스트 게시판의 일반 게시글 행만 추출한다.
  const rows=html.match(/<tr[^>]*class=["'][^"']*ub-content[^"']*["'][\s\S]*?<\/tr>/gi)||[];
  for(const row of rows){
   const linkMatch=row.match(/<a[^>]*class=["'][^"']*icon_txt[^"']*["'][^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/i)
     ||row.match(/<td[^>]*class=["'][^"']*gall_tit[^"']*["'][^>]*>[\s\S]*?<a[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/i);
   if(!linkMatch)continue;
   const href=decodeHtml(linkMatch[1]);
   const title=clean(decodeHtml(linkMatch[2].replace(/<[^>]*>/g," ")));
   if(!title)continue;
   const recMatch=row.match(/<td[^>]*class=["'][^"']*gall_recommend[^"']*["'][^>]*>([\s\S]*?)<\/td>/i);
   const recommend=Number((recMatch?.[1]||"").replace(/<[^>]*>/g,"").replace(/[^\d]/g,""))||0;
   const url=new URL(href,output.sourceUrl).href;
   if(!output.posts.some(p=>p.url===url))output.posts.push({title,recommend,url});
   if(output.posts.length>=20)break;
  }
  if(!output.posts.length)throw new Error("게시글 목록을 읽지 못했습니다. DC인사이드 페이지 구조 또는 접근 제한을 확인해 주세요.");
 }catch(error){
  output.error=error.message||"DC인사이드 인기글을 불러오지 못했습니다.";
  console.error("DC인사이드 수집 실패:",output.error);
 }
 fs.writeFileSync("public/dcinside.json",JSON.stringify(output,null,2),"utf8");
 console.log(`DC인사이드 인기글 저장 완료: ${output.posts.length}건`);
}
async function main(){
 const raw=[];
 for(const c of categories){
  const url=`https://news.google.com/rss/search?q=${encodeURIComponent(c.query)}&hl=ko&gl=KR&ceid=KR:ko`;
  try{
   const feed=await parser.parseURL(url);
   for(const item of (feed.items||[]).slice(0,35)){
    raw.push({title:clean(item.title),description:clean(item.contentSnippet||item.content||item.summary||""),link:item.link,pubDate:item.isoDate||item.pubDate,source:clean(item.creator||sourceName(item.link))});
   }
  }catch(e){console.error("RSS 수집 실패",c.name,e.message);}
 }
 if(!raw.length)throw new Error("뉴스 RSS 수집 결과가 없습니다.");
 const grouped=new Map();
 for(const item of raw){
  const key=normalizeTitle(item.title); if(!key)continue;
  if(!grouped.has(key))grouped.set(key,{...item,sources:new Set(),mentions:0});
  const g=grouped.get(key);g.sources.add(item.source);g.mentions++;
  if((item.description||"").length>(g.description||"").length)g.description=item.description;
 }
 const articles=[...grouped.values()].map((x,i)=>{
  const ageHours=Math.max(0,(Date.now()-new Date(x.pubDate||Date.now()).getTime())/36e5);
  const freshness=Math.max(0,24-ageHours)/24;
  const score=Math.round(x.sources.size*18+x.mentions*5+freshness*25);
  return {id:String(i+1),title:x.title,description:summarize(x.description,x.title),url:x.link,source:[...x.sources][0]||x.source,sources:[...x.sources],pubDate:x.pubDate||null,category:categoryFor(x),score,keywords:keywords(x.title+" "+(x.description||"")).slice(0,5)};
 }).sort((a,b)=>b.score-a.score);
 const byCategory={};
 for(const c of categories){
  const list=articles.filter(a=>a.category===c.id).sort((a,b)=>b.score-a.score);
  const freq={};list.forEach(a=>a.keywords.forEach(k=>freq[k]=(freq[k]||0)+1));
  const popular=Object.entries(freq).sort((a,b)=>b[1]-a[1]).slice(0,6).map(x=>x[0]);
  byCategory[c.id]={articles:list.slice(0,15),keywords:popular,trendTitle:list.length?`${c.name} 분야 핵심 흐름: ${popular.slice(0,3).join(" · ")}`:`${c.name} 뉴스 수집 중`};
 }
 const data={updatedAt:new Date().toISOString(),date:new Intl.DateTimeFormat("ko-KR",{timeZone:"Asia/Seoul",dateStyle:"full"}).format(new Date()),rankingBasis:"언론사 중복 보도 수 + 최신성 기반 참고 점수 (실제 조회수 아님)",top:articles.slice(0,15),categories:byCategory,counts:Object.fromEntries(Object.entries(byCategory).map(([k,v])=>[k,v.articles.length]))};
 fs.mkdirSync("public",{recursive:true});fs.writeFileSync("public/data.json",JSON.stringify(data,null,2),"utf8");
 await collectDcInside();
 console.log(`뉴스 데이터 저장 완료: ${raw.length}건 수집, ${articles.length}개 이슈`);
}
main().catch(e=>{console.error(e);process.exit(1);});
