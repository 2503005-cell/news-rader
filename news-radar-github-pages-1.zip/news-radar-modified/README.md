# NEWS RADAR — GitHub Pages 배포용

이 버전은 서버 설치 없이 GitHub Pages로 공개하는 정적 사이트입니다.
GitHub Actions가 한국 시간 매일 00:00(UTC 전날 15:00)에 RSS 뉴스를 수집하고 `public/data.json`을 갱신한 뒤 사이트를 배포합니다.

## GitHub에 올리는 방법

1. GitHub에서 `news-radar`라는 새 Repository를 만듭니다.
   - Public 권장
   - README / .gitignore / License는 추가하지 말고 빈 저장소로 생성
2. 이 ZIP 압축을 풉니다.
3. 압축 푼 폴더 안의 파일과 `.github` 폴더를 저장소 최상위에 업로드합니다.
   - `.github/workflows/news.yml` 경로가 유지되어야 합니다.
   - GitHub 웹 업로드에서 폴더 구조가 어렵다면 GitHub Desktop을 사용해도 됩니다.
4. 저장소의 Settings → Pages로 이동합니다.
5. Build and deployment → Source를 `GitHub Actions`로 선택합니다.
6. Actions 탭에서 `Update news and deploy site` 실행 상태를 확인합니다.
7. 완료되면 저장소 Settings → Pages에 표시되는 `https://계정명.github.io/저장소명/` 주소로 접속합니다.

## 자동 업데이트
- GitHub Actions schedule: `0 15 * * *` (UTC) = 한국 시간 매일 00:00
- GitHub Actions 예약 실행은 시스템 부하에 따라 예정 시각보다 늦어질 수 있습니다.
- 최초 배포는 Actions 탭에서 workflow가 성공해야 사이트가 표시됩니다.
- 저장소의 Actions 기능이 활성화되어 있어야 합니다.

## 순위 정확도 관련
실제 기사 조회수는 뉴스 RSS에서 제공되지 않으므로 실제 조회수 순위라고 표시하지 않습니다.
언론사 중복 보도 수와 최신성을 조합한 참고 점수입니다. 키워드는 수집된 제목과 요약에서 빈도 기반으로 추출합니다.

## DC인사이드 인기글 원문 보기
- 메인 화면의 NEWS RADAR 로고를 2.5초 안에 5번 누르면 인기글 창이 열립니다.
- 인기글 제목을 누르면 같은 창 안에서 수집된 본문과 이미지를 읽을 수 있습니다.
- 본문 수집이 제한된 글은 `DC인사이드 원문 페이지 열기` 링크로 이동할 수 있습니다.
- 원문 수집은 GitHub Actions 실행 시 수행되며, DC인사이드의 페이지 구조나 접근 정책에 따라 일부 글의 본문·이미지가 표시되지 않을 수 있습니다.
